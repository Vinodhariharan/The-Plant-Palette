const images = [
    {
        id: 1,
        src: require("../../assets/images/cover2 (2).png"),
        alt: "Image 1",
    },
    {
        id: 2,
        src: require("../../assets/images/cover2.png"),
        alt: "Image 2 ",
    },
    {
        id: 3,
        src: require("../../assets/images/cover3.png"),
        alt: "Image 3 ",
    },
    
];
export default images;